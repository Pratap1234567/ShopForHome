package com.example.LoginRegisterClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginRegisterClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
