package com.example.ProductsMenu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductsMenuApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductsMenuApplication.class, args);
	}

}
