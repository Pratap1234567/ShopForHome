package com.example.ProductsMenu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductsMenuApplicationTests {

	@Test
	void contextLoads() {
	}

}
