package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringEmailSenderApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringEmailSenderApplication.class, args);
	}

}
